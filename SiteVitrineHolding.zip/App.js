
    import React from 'react';
    import { Card, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { motion } from 'framer-motion';

    const App = () => {
      return (
        <div className="min-h-screen bg-gray-100 p-8">
          <div className="max-w-7xl mx-auto">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
              <h1 className="text-5xl font-bold text-center mb-8">GT Capital Participation</h1>
              <p className="text-center text-xl mb-8">
                🔗 Maîtriser, structurer et faire croître vos actifs.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardContent>
                    <h2 className="text-2xl font-semibold mb-4">Gestion & Développement d’Actifs 📈</h2>
                    <p>Stratégies globales pour maximiser et sécuriser vos actifs sur le long terme.</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent>
                    <h2 className="text-2xl font-semibold mb-4">Détention & Gestion de Sociétés & Immeubles 💼</h2>
                    <p>Structuration, acquisition, et optimisation de patrimoines immobiliers et de participations diverses.</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent>
                    <h2 className="text-2xl font-semibold mb-4">Rachat & Gestion d’Entreprises 🏢</h2>
                    <p>Acquisition stratégique, restructuration, et croissance d'entreprises pour une rentabilité durable.</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent>
                    <h2 className="text-2xl font-semibold mb-4">Services Comptables & Gestion Administrative 📊</h2>
                    <p>Assistance comptable simplifiée, suivi financier et gestion optimisée de projets.</p>
                  </CardContent>
                </Card>
              </div>
              <div className="text-center mt-8">
                <Button>Contactez-nous</Button>
              </div>
            </motion.div>
          </div>
        </div>
      );
    };

    export default App;
    